package com.example.christianbarlow.listapplication;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

public class techImageActivity extends AppCompatActivity {
    ImageView techImage;
    String companyName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.techimage);

        techImage = (ImageView) findViewById(R.id.imageView);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null){
            companyName = bundle.getString("TechCompanies");
            if(companyName.equalsIgnoreCase("Apple")){
                techImage.setImageDrawable(ContextCompat.getDrawable(techImageActivity.this, R.drawable.apple));
            }
            else if(companyName.equalsIgnoreCase("Hewlett-Packard")){
                techImage.setImageDrawable(ContextCompat.getDrawable(techImageActivity.this, R.drawable.hp));
            }
            else if(companyName.equalsIgnoreCase("IBM")){
                techImage.setImageDrawable(ContextCompat.getDrawable(techImageActivity.this, R.drawable.ibm));
            }
            else if(companyName.equalsIgnoreCase("Amazon")){
                techImage.setImageDrawable(ContextCompat.getDrawable(techImageActivity.this, R.drawable.amazon));
            }
            else if(companyName.equalsIgnoreCase("Microsoft")){
                techImage.setImageDrawable(ContextCompat.getDrawable(techImageActivity.this, R.drawable.microsoft));
            }
            else if(companyName.equalsIgnoreCase("Google")){
                techImage.setImageDrawable(ContextCompat.getDrawable(techImageActivity.this, R.drawable.google));
            }
            else if(companyName.equalsIgnoreCase("Intel")){
                techImage.setImageDrawable(ContextCompat.getDrawable(techImageActivity.this, R.drawable.intel));
            }
            else if(companyName.equalsIgnoreCase("Cisco")){
                techImage.setImageDrawable(ContextCompat.getDrawable(techImageActivity.this, R.drawable.cisco));
            }
            else if(companyName.equalsIgnoreCase("Oracle")){
                techImage.setImageDrawable(ContextCompat.getDrawable(techImageActivity.this, R.drawable.oracle));
            }
            else if(companyName.equalsIgnoreCase("Qualcomm")){
                techImage.setImageDrawable(ContextCompat.getDrawable(techImageActivity.this, R.drawable.qualcomm));
            }
            else if(companyName.equalsIgnoreCase("EMC")){
                techImage.setImageDrawable(ContextCompat.getDrawable(techImageActivity.this, R.drawable.emc));
            }
            else if(companyName.equalsIgnoreCase("Xerox")){
                techImage.setImageDrawable(ContextCompat.getDrawable(techImageActivity.this, R.drawable.xerox));
            }

        }
    }
}
