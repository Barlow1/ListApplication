package com.example.christianbarlow.listapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

public class ListViewActivity extends AppCompatActivity {
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview);

        //String[] techCompanies = {"Apple", "Hewlett-Packard", "IBM", "Amazon"};
        ListAdapter techListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.techCompanies));
        listView = (ListView) findViewById(R.id.listView);
        listView.setAdapter(techListAdapter);

        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Intent intent = new Intent(ListViewActivity.this, techImageActivity.class);
                        intent.putExtra("TechCompanies", listView.getItemAtPosition(position).toString());
                        startActivity(intent);
                    }
                }
                );
    }


}
