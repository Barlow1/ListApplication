package com.example.christianbarlow.listapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class RecycleViewActivity extends AppCompatActivity implements MyAdapter.ItemClickListener {

    MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recycleview);

        ArrayList<String> techCompanyNames = new ArrayList<>();
        techCompanyNames.add("Apple");
        techCompanyNames.add("Hewlett-Packard");
        techCompanyNames.add("IBM");
        techCompanyNames.add("Amazon");
        techCompanyNames.add("Microsoft");
        techCompanyNames.add("Google");
        techCompanyNames.add("Intel");
        techCompanyNames.add("Cisco");
        techCompanyNames.add("Oracle");
        techCompanyNames.add("Qualcomm");
        techCompanyNames.add("EMC");
        techCompanyNames.add("Xerox");

        // set up the RecyclerView
        final RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyAdapter(this, techCompanyNames);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);


    }
    @Override
    public void onItemClick(View view, int position) {
        Intent intent = new Intent(RecycleViewActivity.this, techImageActivity.class);
        intent.putExtra("TechCompanies", adapter.getItem(position).toString());
        startActivity(intent);
    }


}
